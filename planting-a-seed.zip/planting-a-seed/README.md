# Planting a Seed

Interaction study: drag a seed over a planting hole and release it to drop it in with a bouncy, physical landing; miss, and it springs back to try again. See `STUDY.md` for the full breakdown.

## Run

No dependencies or build step. Open `index.html` directly in a modern browser, or serve the folder:

```bash
npx serve .            # or
python3 -m http.server 8000
```

Then open the printed URL (e.g. http://localhost:8000).

Notes:
- Works with mouse, touch, and pen; with the seed focused, Enter or Space drops it.
- The page background and button follow the system light or dark setting.
- The CSS names "IBM Plex Sans" but doesn't load it; it falls back to Helvetica Neue / Arial, exactly as the published page does.

## Files
- `index.html`: the complete study (HTML, CSS, inline SVG, JS), exported unchanged from the published artifact.
- `STUDY.md`: what it does, components, states, and where each behavior lives in the code.
- `package.json`: optional convenience script (`npm start`).
