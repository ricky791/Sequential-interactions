# Grow a Flower

Interaction study: drag upward from a seed to grow a stem, leaves, a bud, and a full bloom, each stage with its own synthesized sound. See `STUDY.md` for the full breakdown.

## Run

No dependencies or build step. Open `index.html` directly in a modern browser, or serve the folder (recommended so audio, pointer, and `localStorage` behavior matches a hosted page):

```bash
npx serve .            # or
python3 -m http.server 8000
```

Then open the printed URL (e.g. http://localhost:8000).

Notes:
- Sound starts after the first press on the seed or the sound button (browsers require a user gesture to start audio). Headphones help; the sounds are quiet and textural.
- The sound on/off choice is remembered in `localStorage` (`grow-a-flower-sound`).
- Works with mouse, touch, and pen; with the scene focused, `ArrowUp` also grows the flower.

## Files
- `index.html`: the complete study (HTML, CSS, inline SVG, JS), exported unchanged from the published artifact.
- `STUDY.md`: what it does, components, states, and where each behavior lives in the code.
- `package.json`: optional convenience script (`npm start`).
