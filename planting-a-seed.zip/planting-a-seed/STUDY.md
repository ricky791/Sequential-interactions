# Study: Planting a Seed

Single-file interaction study (`index.html`, ~325 lines, vanilla HTML/CSS/SVG/JS, no build step, no dependencies).

## What the study does

A seed hangs above a patch of soil with a planting hole. The user drags the seed and lets go. If it is released **over the hole opening**, it falls in under gravity, bounces three times with decreasing height (squashing on each impact), darkens as it sinks deeper, and settles at the bottom of the hole, after which it is locked. If it is released **anywhere else**, it starts to fall, then springs smoothly back to its starting spot so the user can try again. While dragging, the hole's rim glows when the seed is in position to drop. **Reset** fades the seed back in at its starting spot.

The study explores *targeted placement with forgiving failure*: a clear drop target, live "you're aligned" feedback, a satisfying physical success, and a gentle undo on a miss.

## Main visual and interactive components

| Component | Element / id | Role |
|---|---|---|
| Scene | `<svg id="scene">` (viewBox `0 60 240 232`) | Drawing surface; `overflow: visible` so the seed can be dragged beyond the viewBox within the visible area |
| Gradients + clip | `<defs>`, `#holeClip` | Seed, soil, and hole gradients. `#holeClip` hides any part of the seed below the hole's front lip, so it looks like it drops *into* the hole |
| Soil patch + hole | `<g transform="translate(0 150)">` | Static ground; hole opening centered at (120, 245), radius 30 × 11 |
| Rim glow | `#rimGlow` | White overlay on the hole rim, shown at 0.28 opacity while the seed is aligned |
| Seed | `#seedClip` → `#seedShade` → `#seed` → `#seedArt` | Wrappers each have one job: clip (in-hole), shade (depth darkening + fade-in), position + hover scale (`#seed`, also the focusable button), squash/stretch (`#seedArt`) |
| Focus ring | `.focus-ring` inside `#seedArt` | Dashed ellipse shown on keyboard focus |
| Reset button | `#reset` | Centered below the scene |

## User actions, feedback, states, and transitions

State variable `state` (line 175): `idle | dragging | planting | settled | failing | returning`.

```
idle ──hover──▶ seed scales ×1.08, cursor: grab
idle ──pointerdown on seed──▶ dragging (×1.14, cursor: grabbing; rim glows when aligned)
dragging ──release, aligned──▶ planting ──3 bounces──▶ settled (locked)
dragging ──release, not aligned──▶ failing (0.22 s fall) ──▶ returning (spring home) ──▶ idle
idle ──Enter/Space on focused seed──▶ drop from start position (not aligned → fail → return)
any ──Reset──▶ idle at start, fades back in
```

Alignment rule (`isAligned`, line 194): seed bottom-center within about 16 units horizontally of the hole center **and** no lower than the hole's opening.

| Action | Feedback |
|---|---|
| Hover seed (idle) | Seed eases to 1.08× |
| Grab seed | 1.14×, grabbing cursor; seed follows pointer, clamped to the visible area |
| Drag over hole | Rim glow on (off as soon as you leave alignment or release) |
| Release on hole | Gravity fall (1800 u/s²), seed slides to center, stretches with speed; at the floor it squashes (up to 30%) and rebounds 10, 4, 1.5 units; darkens up to 30% with depth; ends `settled`, cursor default, removed from tab order |
| Release off hole | Short gravity fall (0.22 s) with stretch, then damped spring home (k=160, c=20) with a soft overshoot |
| Reset | All state cleared, clip and glow off, seed re-focusable, opacity animates 0 → 1 |

Reduced motion (`prefers-reduced-motion`): no squash, stretch, or bounces; the seed drops straight in and settles on first contact.

Theming: page background and Reset button follow light/dark (`prefers-color-scheme` or `data-theme` on `<html>`); the scene artwork itself is fixed greyscale.

Accessibility: the seed is a focusable `role="button"`; the SVG has an `aria-label`; there is a visually hidden `<h1>`.

## Where it is implemented (line numbers in `index.html`)

| Lines | What |
|---|---|
| 1 | Host page wrapper (doctype, viewport, base reset) added when the artifact was published |
| 3–75 | CSS: light/dark tokens (5–25), layout, cursors, focus ring, rim-glow transition, Reset button, `.sr-only` |
| 77–152 | Markup: `<main>`, scene SVG (80–142) with `<defs>` and `#holeClip` (81–101), soil + hole + `#rimGlow` (103–124), seed nesting (126–140), Reset button (144–151) |
| 165–173 | Geometry constants: hole `HX/HCY/HRX`, seed scale `S`, `FLOOR`, `START`, `ALIGN_X`, gravity `G`, `BOUNCES` |
| 175–180 | State variables |
| 182–194 | `toScene()`, `visibleBounds()` drag clamp, `isAligned()` |
| 196–197 | `setGlow()`, `setClip()` |
| 199–228 | Pointer handlers: hover, `pointerdown`, `pointermove` (clamp + glow), `release()` |
| 230–234 | `drop()`: branch to `planting` or `failing` |
| 236–239 | Keyboard Enter/Space |
| 241–248 | Reset |
| 250–321 | Frame loop: planting physics and bounces (257–275), failing (276–280), returning spring (281–290), squash spring (292–295), stretch (297–301), hover scale (303–305), fade-in and transforms (307–313), depth shading (314–317) |

### Tunable constants (for the connected prototype)
- Start position `START = {x:120, y:150}` (170); hole `HX=120, HCY=245, HRX=30` (166).
- Alignment tolerance `ALIGN_X` (171), about 16 units.
- Gravity `G = 1800` (172); bounce heights `[10, 4, 1.5]` (173); max squash `0.3` (264).
- Fail duration `0.22 s` (280); return spring `k=160, c=20` (283).
- Hover and grab scales `1.08 / 1.14` (304).

## External dependencies and assets

None required. No scripts, images, or network requests; all artwork is inline SVG (comments name the original sources `seed.svg` and `soil-hole.svg`, already inlined). The CSS asks for the font **"IBM Plex Sans"** but never loads it, so it falls back to Helvetica Neue / Arial unless that font is installed locally. This only affects the Reset label; the published look is the fallback. Uses only standard browser APIs: Pointer Events + pointer capture, `requestAnimationFrame`, `matchMedia`. No sound or haptics.

Integration notes for a multi-study prototype:
- **Sequence fit:** natural first step of *Planting a Seed → Grow a Flower → Pick a Flower*. The `settled` transition (around line 268) is the hook for "study complete", e.g. `window.dispatchEvent(new CustomEvent('study:complete'))`.
- **Visual continuity:** this study and *Grow a Flower* draw the same soil and hole artwork but at different positions and scales (hole at (120, 245) in a 240-wide viewBox here, at (160, 445) in a 320-wide viewBox there). A seamless handoff needs one aligned to the other.
- **Element ids:** logic uses `document.getElementById`; ids like `scene`, `seed`, and `reset` collide with the other studies, so prefix them or mount each study in its own `<iframe>`.
- **Layout:** `body { overflow: hidden }` and the full-height `<main>` assume the study owns the viewport. Unlike the other two studies, this one supports dark mode for the page chrome.
