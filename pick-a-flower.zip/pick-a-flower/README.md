# Pick a Flower

Interaction study: pull a flower until the stem snaps, then drag the freed head around. See `STUDY.md` for the full breakdown.

## Run

No dependencies or build step. Open `index.html` directly in a modern browser, or serve the folder (recommended so audio/pointer behavior matches a hosted page):

```bash
npx serve .            # or
python3 -m http.server 8000
```

Then open the printed URL (e.g. http://localhost:8000).

Notes:
- Sound plays after the first press on the flower (browsers require a user gesture to start audio).
- Haptic buzz on snap works only where `navigator.vibrate` is supported (e.g. Android Chrome).
- Works with mouse, touch, and pen.

## Files
- `index.html` — the complete study (HTML, CSS, inline SVG, JS), exported unchanged from the published artifact.
- `STUDY.md` — what it does, components, states, and where each behavior lives in the code.
- `package.json` — optional convenience scripts (`npm start`).
